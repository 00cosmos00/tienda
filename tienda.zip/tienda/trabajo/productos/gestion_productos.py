class Productos:
    def __init__(self):
        self.productos={}

    def menu_productos(self):
        opcion=0
        while opcion!=4:
            print("\n--- gestion de productos---")
            print("1.   agregar producto")
            print("2.   Listar producto")
            print("3.   Buscar por id a producto")
            print("4.   volver al menu principal")
            
            opcion=int(input("Seleccione una opcion: "))

            if opcion==1:
                print("Opcion 1")
                self.crear()
            elif opcion==2:
                print("Opcion 2")
                self.listado()
            elif opcion==3:
                print("Opcion 3")
                self.consulta()
            elif opcion==4:
                print("Opcion 4")
                self.salir()
                

    def crear(self):
        print("==============================")
        id=int(input("Ingrese el id: "))
        Nombre=input("Ingrese Nombre: ")
        self.productos[id]=(Nombre)
        print("==============================")

    def listado(self):
        print("==============================")
        print("   LISTADO DE productoS   ")
        print("==============================")
        for id in self.productos:
            print("id:",id,"|Nombre:",self.productos[id])

    def consulta(self):
        print("==============================")
        id=int(input("Ingrese id a buscar: "))
        if id in self.productos:
            print("id",id,"|Su nombre es",self.productos[id] )
        else:
            print("No existe el producto")
            print("==============================")

    def salir(self):
        quit

#principal
