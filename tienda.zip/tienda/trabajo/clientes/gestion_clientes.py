class Cliente:
    def __init__(self):
        self.contactos={}

    def menu_cliente(self):
        opcion=0
        
        while opcion!=4:
            print("\n--- gestion de clientes---")
            print("1.   agregar Cliente")
            print("2.   Listar Cliente")
            print("3.   Buscar por Rut a Cliente")
            print("4.   volver al menu principal")
            
            opcion=int(input("Seleccione una opcion: "))

            if opcion==1:
                print("Opcion 1")
                self.crear()
            elif opcion==2:
                print("Opcion 2")
                self.listado()
            elif opcion==3:
                print("Opcion 3")
                self.consulta()
            elif opcion==4:
                print("Opcion 4")
                self.salir()
                

    def crear(self):
        print("==============================")
        Rut=int(input("Ingrese el Rut: "))
        Nombre=input("Ingrese Nombre: ")
        self.contactos[Rut]=(Nombre)
        print("==============================")

    def listado(self):
        print("==============================")
        print("   LISTADO DE CLIENTES   ")
        print("==============================")
        for Rut in self.contactos:
            print("Rut:",Rut,"|Nombre:",self.contactos[Rut])

    def consulta(self):
        print("==============================")
        Rut=int(input("Ingrese rut a buscar: "))
        if Rut in self.contactos:
            print("Rut",Rut,"|Su nombre es",self.contactos[Rut] )
        else:
            print("No existe el cliente")
            print("==============================")

    def salir(self):
        quit

#principal
