from clientes.gestion_clientes import Cliente
from productos.gestion_productos import Productos
def menu_principal():
    cliente= Cliente()
    productos= Productos()
    while True:
        print("""
                gestion productos
              1. gestionar productos
              2. gestionar clientes
              3. salir
              """)
        opcion=int(input("elige  una opcion:"))
        if opcion ==1:
            productos.menu_productos()
        elif opcion == 2:
            cliente.menu_cliente()
        elif opcion== 3:
            quit
menu_principal()